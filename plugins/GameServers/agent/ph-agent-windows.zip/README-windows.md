# Planet Hosts Game Node Agent — Windows

**`ph-agent-installer.exe`** is a self-contained GUI installer. It embeds the
agent engine (`ph-agent.exe`, Node.js built in) plus a setup wizard that collects
everything needed — no Node install or firewall/ISP port-forwarding required.
The agent **connects OUT** to the panel over HTTPS.

## Install
1. Download **`ph-agent-installer.exe`** from **Admin → Games → Game Nodes**.
2. Run it (UAC prompt appears — it registers an auto-start task).
3. Fill in:
   - **Panel URL** — your hosting panel (e.g. `https://planet-hosts.com`)
   - **Node token** — generate one in **Admin → Games → Game Nodes** (the **Gen** button) and paste it here
   - **Agent install folder** — where the agent exe goes (default `%ProgramFiles%\PlanetHostsAgent`)
   - **Game install folder** — where servers/Games are installed (default `C:\PlanetHostsGames`)
   - **Steam login (optional)** — only ticked if you will install games that
     **must be purchased on Steam** (ARK, Valheim…). Enter **your own** Steam
     account. Free/downloadable games use `anonymous` — the panel's own Steam
     settings are never sent to you or the agent.
4. Press **Test Connection** to verify the token, then **Install Agent**.

The agent starts polling immediately and appears **online** in **Admin → Games → Nodes**.

## Change settings later
Edit the `agent-config.json` in the agent install folder, then:
```
Restart-ScheduledTask -TaskName PlanetHostsAgent
```

## Run manually (no install)
```
ph-agent.exe
```
(reads `agent-config.json` in the same folder)

## Back in the panel
- **Admin → Games → Game Nodes** → the node shows **online** with its connected
  IP and location.
- Create a game server and choose this node → install/start/stop are all
  controlled from the panel.

## Notes
- Steam App-ID installs use `steamcmd.exe` (`steam_user`/`steam_pass` in config; leave blank/`anonymous` unless the game must be purchased).
- For a custom game, edit the generated `start.bat` in the server's folder under the install directory.
- The control plane needs no inbound ports. Players reaching the game still need the game port reachable (use Tailscale if your ISP blocks inbound ports).
- `install-agent.ps1` in this package is the older scripted installer (same result) for users who prefer PowerShell.