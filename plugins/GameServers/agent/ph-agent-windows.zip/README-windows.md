# Planet Hosts Game Node Agent — Windows

**`ph-agent.exe`** is a self-contained executable (Node.js built in) that lets the
Planet Hosts panel control game servers on this computer — no installing Node or
opening firewall/ISP ports required. It **connects OUT** to the panel over HTTPS.

## Install
1. Copy this whole folder to the Windows machine (or a USB stick).
2. Right-click **`install-agent.ps1`** → **Run with PowerShell**.
3. Enter:
   - **Panel URL** (e.g. `https://planet-hosts.com`)
   - **Node token** — create the node in **Admin → Games → Game Nodes** and copy its token here
   - **Game install directory** (e.g. `C:\PlanetHostsGames`)
4. It installs the exe to `C:\Program Files\PlanetHostsAgent`, writes
   `agent-config.json`, and registers a **scheduled task that auto-starts at boot**.

The agent starts polling immediately and appears **online** in **Admin → Games → Nodes**.

## Change settings later
Edit `C:\Program Files\PlanetHostsAgent\agent-config.json`, then:
```
Restart-ScheduledTask -TaskName PlanetHostsAgent
```

## Run manually (no install)
```
ph-agent.exe
```
(reads `agent-config.json` in the same folder)

## Back in the panel
- **Admin → Games → Game Nodes** → the node should show **online**.
- Create a game server and choose this node → install/start/stop are all controlled from the panel.

## Notes
- Steam App-ID installs use `steamcmd.exe` (`steam_user`/`steam_pass` in config; use `anonymous` when possible).
- For a custom game, edit the generated `start.bat` in the server's folder under the install directory.
- The control plane needs no inbound ports. Players reaching the game still need the game port reachable (use Tailscale if your ISP blocks inbound ports).
