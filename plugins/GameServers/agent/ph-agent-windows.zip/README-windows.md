# Planet Host Game Node Agent — Windows

**`ph-agent-installer.exe`** is a self-contained GUI installer. It embeds the
agent engine (`ph-agent.exe`, Node.js built in), a **taskbar tray manager**
(`ph-agent-tray.exe`), plus a setup wizard that collects everything needed — no
Node install or firewall/ISP port-forwarding required. The agent **connects
OUT** to the panel over HTTPS.

## Install
1. Download **`ph-agent-installer.exe`** from **Admin → Games → Game Nodes**.
2. Run it (UAC prompt appears).
3. Fill in:
   - **Panel URL** — your hosting panel (e.g. `https://planet-hosts.com`)
   - **Node token** — generate one in **Admin → Games → Game Nodes** (the **Gen** button) and paste it here
   - **Agent install folder** — where the agent exe goes (default `%ProgramFiles%\PlanetHostsAgent`)
   - **Game install folder** — where servers/ Games are installed (default `C:\PlanetHostsGames`)
   - **Run mode** — **Windows Service** (recommended) keeps the agent online 24/7
     even with nobody logged in; **background task** only runs while a user is signed in
   - **Steam login (optional)** — only ticked if you will install games that
     **must be purchased on Steam** (ARK, Valheim…). Enter **your own** Steam
     account. Free/downloadable games use `anonymous`.
4. Press **Test Connection**, then **Install Agent**.

The agent starts polling immediately and appears **online** in **Admin → Games → Nodes**.

## Tray icon + desktop shortcut
After install you get:
- A **tray icon** in the taskbar (right-click for the menu)
- a **"Planet Host Agent"** shortcut on the desktop and Start menu, and
- an **"Uninstall Planet Host Agent"** shortcut.

Right-click the tray icon (or open its Control Panel) to:
- **Start / Stop / Restart** the agent
- View **status** (running/stopped, service state, panel online/offline)
- **Open Agent Folder** (file location) and **Edit Config**
- **Add/Remove drives** (*Game Locations*) — choose extra install folders on
  other hard drives; new servers will install there
- **Install / Uninstall Service** — register/remove the Windows service so the
  agent survives logoff and reboot
- **Uninstall Agent** — stops everything, removes the service/auto-start,
  deletes the desktop/Start-menu shortcuts, and deletes the installed files.

## Run manually (no install)
```
ph-agent.exe
```
(reads `agent-config.json` in the same folder)

## Change settings later
- Tray icon → **Edit Config** or **Game Locations** to add more drives.
- Or edit the `agent-config.json` in the agent install folder:
  - `locations` — array of install roots (e.g. `["C:\\PlanetHostsGames","D:\\Games"]`);
    put the drive you want as the default first.
- The tray app rewrites the config when you add/remove locations and restarts the agent automatically.

## Development / rebuild
Run `build.ps1` in the `win/` folder (uses the built-in .NET Framework csc).
`ph-agent.exe` is the pkg-bundled build of `../agent.js`:
```
pkg ../agent/agent.js --targets node18-win-x64 --output win/ph-agent.exe
```

## Back in the panel
- **Admin → Games → Game Nodes** → each node shows its connected IP, geo
  location, and the **drives/install locations** the agent reports, with free
  disk space.
- Create a game server and choose this node (optionally a specific drive) →
  install/start/stop are all controlled from the panel.

## Notes
- Only one agent instance runs per machine (a pid guard prevents the service
  and a manual copy double-polling).
- Steam App-ID installs use `steamcmd.exe` (`steam_user`/`steam_pass`; leave blank/`anonymous` unless the game must be purchased).
- For a custom game, edit the generated `start.bat` in the server's folder.
- The control plane needs no inbound ports. Players reaching the game still need the game port reachable (use Tailscale if your ISP blocks inbound ports).
- `install-agent.ps1` in this package is the older scripted installer for users who prefer PowerShell.